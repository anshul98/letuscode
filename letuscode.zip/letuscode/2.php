<?php
$arr[]=array("Anshul","Shitty");
echo json_encode($arr);
?>